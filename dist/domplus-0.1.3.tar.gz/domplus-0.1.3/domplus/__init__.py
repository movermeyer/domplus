# -*- coding: utf-8 -*-

__author__ = 'Eduardo Basilio'
__email__ = 'eduardoafonsobasilio@gmail.com'
__version__ = '0.1.3'
