========
Usage
========

To use domplus in a project::

    import domplus
