============
Installation
============

At the command line::

    $ easy_install domplus

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv domplus
    $ pip install domplus
